function Header(props) {
return (
        <div>
            <p>{props.hdata} </p>
            <button disabled={!props.hasData} onClick={props.da} className="btn btn-warning">delete All Users</button>
        </div>
    )
}
export default Header