import { add } from "./math";

console.log(add(4,8));