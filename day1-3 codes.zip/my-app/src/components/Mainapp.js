import { useEffect, useState } from "react"
import AddUser from "./AddUser"
import Footer from "./Footer"
import Header from "./Header"
import UserData from "./UserData"
function MainApp() {

    // initialize the state
    const [users, setUsers] = useState([])
    const [department, setDepartment] = useState([])

    useEffect(()=>{
        localStorage.setItem('db',JSON.stringify(users))
    },[users])

    const deleteUser = (usr) => {
        setUsers(users.filter((user) => user !== usr))
    }
    const addUser = (user, dept) => {

        setUsers([...users, user])
        setDepartment([...department, dept])
    }

    const deleteAll = () => {
        setUsers([])
    }
    const headerData = 'welcome to header'

    return (
        <div>
            <div class="card">
                <div className="card-header">
                    <Header hdata={headerData} da={deleteAll} hasData={users.length > 0} />
                </div>
                <div className="card-body">
                    <AddUser au={addUser} />
                    <p>MainApp Component</p>
                    <UserData udata={users} depts={department} du={deleteUser} />
                </div>
                <div className="card-footer">
                    <Footer />
                </div>
            </div>






        </div>
    )
}
export default MainApp