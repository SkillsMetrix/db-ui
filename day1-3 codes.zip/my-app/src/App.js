import logo from './logo.svg';
import './App.css';
import React, { Suspense } from 'react'
//import RestApp from './components/RestApp';
const RestApp = React.lazy(() => delay(import('./components/RestApp')))
function App() {
  return (
    <div className="App">
      <Suspense fallback={<div>Loading.....</div>}>
        <RestApp />
      </Suspense>

    </div>
  );
}

export default App;
function delay(module) {
  return new Promise(res => {
    setTimeout(res, 2000)
  }).then(() => module)
}