import logo from './logo.svg';
import './App.css';
import Counter from './components/Counter';
import AuthApp from './components/AuthApp';

function App() {
  return (
    <div className="App">
      <AuthApp/>
    </div>
  );
}

export default App;
