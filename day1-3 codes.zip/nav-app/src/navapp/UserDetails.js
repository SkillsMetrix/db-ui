import React from 'react';

function UserDetails(props) {
    return (
        <div>
            UserDetails
        </div>
    );
}

export default UserDetails;