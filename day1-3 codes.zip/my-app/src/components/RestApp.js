


import React, { useEffect, useState } from 'react';
import axios from 'axios'
import RestAppData from './RestAppData';
const URL = 'https://jsonplaceholder.typicode.com/users'
function RestApp(props) {
    const [users, setUsers] = useState([])
    
    const loadUsers=()=>{
        axios.get(URL).then((response) => response.data)
        .then((data) => {
            console.log(data);
            setUsers(data)
        })
    }
    return (
        <div>
            <p> Restfull Application</p>
            <button onClick={loadUsers}>Load Users</button>
            <hr/>
            <RestAppData data={users} />

        </div>
    );
}

export default RestApp;