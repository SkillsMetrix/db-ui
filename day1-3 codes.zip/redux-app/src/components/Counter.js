


 import { useDispatch, useSelector } from 'react-redux'
import { dec, inc } from '../redux/actions/counterAction';
function Counter(props) {
    const counter= useSelector(state => state.mycounter)
    const dispatch= useDispatch()
    return (
        <div>
            <button onClick={()=> dispatch(inc())}>INC</button>
            <button onClick={()=> dispatch(dec())}>DEC</button>
            <hr/>
            <p> The current state is  : {counter}</p>
        </div>
    );
}

export default Counter;