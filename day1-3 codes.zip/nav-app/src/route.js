import Login from "./navapp/Login";
import Register from "./navapp/Register";


export const routes=[
    {path:'/login', element:<Login/>},
    {path:'/register', element:<Register/>},
]