import React from 'react';

function Register(props) {
    return (
        <div>
            Register
        </div>
    );
}

export default Register;