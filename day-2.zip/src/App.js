import logo from './logo.svg';
import './App.css';
import MainApp from './components/Mainapp';
import RestApp from './components/RestApp';

function App() {
  return (
    <div className="App">
     
      <RestApp/>
    </div>
  );
}

export default App;
