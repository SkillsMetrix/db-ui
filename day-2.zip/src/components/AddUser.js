
 export default function AddUser(props)   {

     const addUser = (e) => {
        e.preventDefault()
        props.au(e.target.elements.uname.value, e.target.elements.dept.value)
}
           return (
            <div>
                <form onSubmit={addUser}>
                    <input type='text' name='uname' placeholder='Enter Username' required minLength={6}/>
                    <input type='text' name='dept' placeholder='Enter Depertment' />
                    <button className='btn btn-primary'>Add</button>
                </form>

            </div>
        )
    }
