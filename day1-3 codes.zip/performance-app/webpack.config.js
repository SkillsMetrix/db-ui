const path = require('path');
const {BundleAnalyzerPlugin} = require('webpack-bundle-analyzer')
module.exports = {
    mode: "production",
    entry: './index.js',
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js',
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: "babel-loader",
                    options: {
                        presets: ["@babel/preset-env"],
                    }
                }
            }
        ]
    },
    // tree shaking to eleme dead code and unused code
    optimization: {
        usedExports:true
    },
plugins:[new BundleAnalyzerPlugin()]
};