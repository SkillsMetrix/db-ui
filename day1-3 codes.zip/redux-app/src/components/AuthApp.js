
import React from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { login, logout } from '../redux/actions/authAction';
function AuthApp(props) {
    const isAllowed= useSelector(state=> state.myauth)
    const dispatch= useDispatch()
    return (
        <div>
            <button onClick={()=>dispatch(login())}>Login</button>
            <button onClick={()=>dispatch(logout())}>LogOut</button>
            <hr/>
            {isAllowed ? (
                <div>
                    <p>Congratulations.....! Use code PPOGJ890 to avail 50 % of discount</p>
                </div>
            ):(
                <p>Please login to View the Offer</p>
            )}
        </div>
    );
}

export default AuthApp;