


import React from 'react';

function RestAppData(props) {
    return (
        <div>
           {props.data.map((data)=>(
    <div>{data.name}----{data.email}</div>
  ))} 
        </div>
    );
}

export default RestAppData;